﻿ public class Grenades
    {
        public const double Weight = 1.0;

        public Grenades(string name) 
          
        {
        }
    }
