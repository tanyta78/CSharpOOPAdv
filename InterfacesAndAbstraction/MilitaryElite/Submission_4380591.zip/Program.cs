﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    public static void Main()
    {
        var engine = new Engine();
        engine.Start();

        foreach (var soldier in engine.Creator.Soldiers)
        {
            Console.WriteLine(soldier.ToString());
        }
    }
}