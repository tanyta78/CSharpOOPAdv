﻿ public class BulletproofVest
    {
        public const double BulletproofVestWeight = 3.4;

        public BulletproofVest(string name)
            
        {
        }
    }
