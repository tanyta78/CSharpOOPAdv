﻿
    public class Shield
    {
        public const double Weight = 3.7;

        public Shield(string name)
            
        {
        }
    }
