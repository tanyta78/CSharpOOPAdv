﻿namespace RecyclingStation.BusinestLayer.Contracts.IO
{
   public interface IReader
   {
       string ReadLine();
   }
}
