﻿public enum Light
{
    Red,
    Green,
    Yellow
}