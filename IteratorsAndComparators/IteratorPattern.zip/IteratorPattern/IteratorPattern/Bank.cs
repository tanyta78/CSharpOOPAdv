﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IteratorPattern
{
public class Bank
{
    public string Manager
    {
        get;
        set;
    }

    public string Accountant
    {
        get;
        set;
    }

    public string Cashier
    {
        get;
        set;
    }
}    
}
