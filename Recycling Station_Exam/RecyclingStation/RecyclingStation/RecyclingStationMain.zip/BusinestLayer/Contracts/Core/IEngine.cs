﻿namespace RecyclingStation.BusinestLayer.Contracts.Core
{
  public interface IEngine
  {
      void Run();
  }
}
